﻿using NavalVessels.Core.Contracts;

namespace NavalVessels.Core
{
    public class Controller : IController
    {
        public string AssignCaptain(string selectedCaptainName, string selectedVesselName)
        {
            throw new System.NotImplementedException();
        }

        public string AttackVessels(string attackingVesselName, string defendingVesselName)
        {
            throw new System.NotImplementedException();
        }

        public string CaptainReport(string captainFullName)
        {
            throw new System.NotImplementedException();
        }

        public string HireCaptain(string fullName)
        {
            throw new System.NotImplementedException();
        }

        public string ProduceVessel(string name, string vesselType, double mainWeaponCaliber, double speed)
        {
            throw new System.NotImplementedException();
        }

        public string ServiceVessel(string vesselName)
        {
            throw new System.NotImplementedException();
        }

        public string ToggleSpecialMode(string vesselName)
        {
            throw new System.NotImplementedException();
        }

        public string VesselReport(string vesselName)
        {
            throw new System.NotImplementedException();
        }
    }
}
