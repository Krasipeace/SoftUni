﻿namespace BorderControl.Models.Interfaces
{
    public interface IIdentify
    {
        public string Id { get; set; }
    }
}

