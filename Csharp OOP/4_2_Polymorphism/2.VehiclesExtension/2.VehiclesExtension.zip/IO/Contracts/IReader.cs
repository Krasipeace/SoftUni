﻿namespace Vehicles.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
