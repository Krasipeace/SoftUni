﻿namespace Invoices.Data.Models.Enums
{
    public enum CurrencyType
    {
        BGN = 0,
        EUR = 1,
        USD = 2
    }
}
